"""
BA ANALYSIS AGENT — SKELETON
=============================
OPENCODE INSTRUCTIONS:
  1. Read CLAUDE.md and .specify/plan.md before editing this file
  2. Replace every ⟨FILL: ...⟩ with the correct value for this project
  3. Delete ⟨OPTION⟩ blocks that don't apply
  4. Save as: 04_Python/⟨FILL: project_slug⟩_analysis_agent.py
  5. Run with: python ⟨FILL: project_slug⟩_analysis_agent.py

What this agent does automatically:
  1. Loads and validates all cleaned source files
  2. Runs full EDA (summary stats, time trends, segment breakdown, geography)
  3. Detects outliers across all numeric columns
  4. Calculates all KPIs defined in CLAUDE.md Section 5
  5. Saves every output to the correct folder
  6. Prints a plain-English executive summary at the end

Requirements:
  pip install pandas numpy scipy plotly openpyxl
"""

import pandas as pd
import numpy as np
from scipy import stats
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import os
from datetime import datetime

# ── CONFIG ───────────────────────────────────────────────────────────────────
# OPENCODE: fill every value below from CLAUDE.md before running

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

PATHS = {
    # OPENCODE: set the master joined file name from plan.md P3
    "master":     os.path.join(PROJECT_ROOT, "02_Cleaned_Data", "⟨FILL: master_filename⟩.csv"),

    # OPENCODE: add any additional supporting tables needed for segment/category analysis
    # ⟨OPTION: remove or add entries as needed⟩
    "⟨FILL: supporting_table_1_key⟩": os.path.join(PROJECT_ROOT, "02_Cleaned_Data", "⟨FILL: filename⟩.csv"),
    "⟨FILL: supporting_table_2_key⟩": os.path.join(PROJECT_ROOT, "02_Cleaned_Data", "⟨FILL: filename⟩.csv"),

    "kpi_out":    os.path.join(PROJECT_ROOT, "02_Cleaned_Data", "kpi_tables"),
    "eda_out":    os.path.join(PROJECT_ROOT, "07_AI_Outputs"),
    "charts_out": os.path.join(PROJECT_ROOT, "07_AI_Outputs", "charts"),
}

# OPENCODE: set benchmarks from CLAUDE.md Section 5 (KPI targets)
BENCHMARKS = {
    "⟨FILL: kpi_1_slug⟩": ⟨FILL: target_value_as_number⟩,
    "⟨FILL: kpi_2_slug⟩": ⟨FILL: target_value_as_number⟩,
    "⟨FILL: kpi_3_slug⟩": ⟨FILL: target_value_as_number⟩,
    # OPENCODE: add one entry per KPI that has a benchmark
}

# OPENCODE: choose outlier method — "iqr" is standard, "zscore" for normal distributions
OUTLIER_METHOD = "iqr"
OUTLIER_IQR_MULTIPLIER = 1.5
OUTLIER_ZSCORE_THRESHOLD = 3.0

# OPENCODE: list all date columns that need parsing on load
DATE_COLUMNS = [
    "⟨FILL: date_column_1⟩",
    "⟨FILL: date_column_2⟩",
    # add more as needed
]

# OPENCODE: list the numeric columns to run outlier detection on
OUTLIER_COLUMNS = [
    "⟨FILL: numeric_column_1⟩",
    "⟨FILL: numeric_column_2⟩",
    "⟨FILL: numeric_column_3⟩",
    # add more as needed
]

# OPENCODE: list the required columns — agent will fail fast if any are missing
REQUIRED_COLUMNS = [
    "⟨FILL: id_column⟩",
    "⟨FILL: entity_id_column⟩",
    "⟨FILL: primary_date_column⟩",
    "⟨FILL: primary_value_column⟩",
    "⟨FILL: time_period_column⟩",       # e.g. order_month, week, quarter
    "⟨FILL: geographic_column⟩",        # e.g. state, region, country
    "⟨FILL: performance_flag_column⟩",  # e.g. is_late, is_resolved, is_returned
    "⟨FILL: satisfaction_column⟩",      # e.g. review_score, nps, rating
]

# ── SETUP ─────────────────────────────────────────────────────────────────────

for path in [PATHS["kpi_out"], PATHS["eda_out"], PATHS["charts_out"]]:
    os.makedirs(path, exist_ok=True)

log_lines = []

def log(msg, section=False):
    line = f"\n{'='*60}\n{msg}\n{'='*60}" if section else f"  {msg}"
    print(line)
    log_lines.append(line)

def save_csv(df, filename, subfolder="kpi_out"):
    path = os.path.join(PATHS[subfolder], filename)
    df.to_csv(path, index=False)
    log(f"Saved: {filename} ({len(df):,} rows)")
    return path

def save_chart(fig, filename):
    path = os.path.join(PATHS["charts_out"], filename)
    fig.write_html(path)
    log(f"Chart saved: {filename}")

# ── STEP 1: LOAD & VALIDATE ───────────────────────────────────────────────────

log("STEP 1 — LOADING DATA", section=True)

master = pd.read_csv(PATHS["master"], parse_dates=DATE_COLUMNS)

log(f"Master dataset: {len(master):,} rows × {master.shape[1]} columns")
log(f"Date range: {master['⟨FILL: primary_date_column⟩'].min().date()} → {master['⟨FILL: primary_date_column⟩'].max().date()}")

missing_cols = [c for c in REQUIRED_COLUMNS if c not in master.columns]
if missing_cols:
    raise ValueError(f"Master dataset missing required columns: {missing_cols}")
log("All required columns present ✓")

# OPENCODE: load additional tables if they exist — add/remove as needed per plan.md
⟨FILL: supporting_table_1_key⟩ = (
    pd.read_csv(PATHS["⟨FILL: supporting_table_1_key⟩"])
    if os.path.exists(PATHS["⟨FILL: supporting_table_1_key⟩"]) else None
)

# ── STEP 2: EDA ───────────────────────────────────────────────────────────────

log("STEP 2 — EXPLORATORY DATA ANALYSIS", section=True)

eda_results = {}

# 2a. Numeric summary
numeric_summary = master[OUTLIER_COLUMNS].describe().T.round(2)
numeric_summary["null_count"] = master[OUTLIER_COLUMNS].isnull().sum()
numeric_summary["null_pct"] = (master[OUTLIER_COLUMNS].isnull().mean() * 100).round(2)
save_csv(numeric_summary.reset_index().rename(columns={"index": "column"}),
         "eda_numeric_summary.csv", "eda_out")

# 2b. Primary metric over time
# OPENCODE: set time_period_col, primary_value_col, count_col from CLAUDE.md
time_period_col   = "⟨FILL: time_period_column⟩"
primary_value_col = "⟨FILL: primary_value_column⟩"
count_col         = "⟨FILL: id_column⟩"

trend = (
    master.groupby(time_period_col)
    .agg(
        total_value=(primary_value_col, "sum"),
        record_count=(count_col, "count"),
    )
    .reset_index()
    .sort_values(time_period_col)
)
trend["avg_value"]        = (trend["total_value"] / trend["record_count"]).round(2)
trend["mom_change_pct"]   = trend["total_value"].pct_change().mul(100).round(2)
trend["total_value"]      = trend["total_value"].round(2)
save_csv(trend, "eda_primary_metric_trend.csv", "eda_out")
eda_results["trend"] = trend

# Trend chart
fig_trend = make_subplots(specs=[[{"secondary_y": True}]])
fig_trend.add_trace(go.Bar(
    x=trend[time_period_col], y=trend["record_count"],
    name="⟨FILL: count label, e.g. Order Count⟩",
    opacity=0.4, marker_color="#94a3b8"), secondary_y=False)
fig_trend.add_trace(go.Scatter(
    x=trend[time_period_col], y=trend["total_value"],
    name="⟨FILL: value label, e.g. Total Revenue⟩",
    mode="lines+markers", line=dict(color="#0f172a", width=2.5)), secondary_y=True)
fig_trend.update_layout(
    title="⟨FILL: chart title — primary metric + project name + date range⟩",
    xaxis_tickangle=45, plot_bgcolor="white")
save_chart(fig_trend, "eda_primary_metric_trend.html")

# 2c. Performance by segment
# OPENCODE: set segment_col from CLAUDE.md — e.g. category_english, product_type, department
segment_col = "⟨FILL: segment_column⟩"

# ⟨OPTION: if segment requires a join to another table, do it here — otherwise delete⟩
# master = master.merge(⟨FILL: table⟩[["⟨FILL: join_key⟩", segment_col]], on="⟨FILL: join_key⟩", how="left")
# master[segment_col] = master[segment_col].fillna("⟨FILL: default_label⟩")

if segment_col in master.columns:
    segment = (
        master.groupby(segment_col)
        .agg(
            total_value=(primary_value_col, "sum"),
            record_count=(count_col, "count"),
            avg_value=(primary_value_col, "mean"),
        )
        .reset_index()
        .sort_values("total_value", ascending=False)
    )
    segment["value_share_pct"] = (segment["total_value"] / segment["total_value"].sum() * 100).round(2)
    segment["cumulative_pct"]  = segment["value_share_pct"].cumsum().round(2)
    segment = segment.round(2)
    save_csv(segment, f"eda_by_{segment_col}.csv", "eda_out")
    eda_results["segment"] = segment

    top_n = segment.head(15)
    fig_seg = px.bar(
        top_n, x="total_value", y=segment_col, orientation="h",
        title=f"⟨FILL: primary metric⟩ by {segment_col.replace('_', ' ').title()} — Top 15",
        color="value_share_pct", color_continuous_scale="Blues",
        text=top_n["value_share_pct"].map(lambda x: f"{x:.1f}%"))
    fig_seg.update_layout(yaxis=dict(autorange="reversed"),
                           plot_bgcolor="white", coloraxis_showscale=False)
    save_chart(fig_seg, f"eda_by_{segment_col}.html")

# 2d. Geography
geo_col = "⟨FILL: geographic_column⟩"
entity_col = "⟨FILL: entity_id_column⟩"
perf_flag_col = "⟨FILL: performance_flag_column⟩"
sat_col = "⟨FILL: satisfaction_column⟩"

geo = (
    master.groupby(geo_col)
    .agg(
        entity_count=(entity_col, "nunique"),
        record_count=(count_col, "count"),
        total_value=(primary_value_col, "sum"),
        avg_value=(primary_value_col, "mean"),
        benchmark_met_rate=(perf_flag_col, lambda x: (x == 0).mean() * 100),  # OPENCODE: adjust == 0 or == 1 depending on flag meaning
        avg_satisfaction=(sat_col, "mean"),
    )
    .reset_index()
    .sort_values("total_value", ascending=False)
)
geo["value_share_pct"] = (geo["total_value"] / geo["total_value"].sum() * 100).round(2)
geo = geo.round(2)
save_csv(geo, "eda_geography.csv", "eda_out")
eda_results["geo"] = geo

# 2e. Entity behaviour (new vs returning)
entity_behaviour = (
    master.groupby(entity_col)
    .agg(
        record_count=(count_col, "count"),
        total_value=(primary_value_col, "sum"),
        first_activity=(time_period_col, "min"),
    )
    .reset_index()
)
entity_behaviour["entity_type"] = np.where(
    entity_behaviour["record_count"] > 1, "returning", "new"
)
save_csv(entity_behaviour, "eda_entity_behaviour.csv", "eda_out")
eda_results["entity_behaviour"] = entity_behaviour

# 2f. Operational performance vs satisfaction
# OPENCODE: define delivery_bucket equivalent for this project
# e.g. for response time, NPS bands, processing days
operational_col = "⟨FILL: operational_metric_column⟩"  # e.g. delivery_days, response_time_hours

if operational_col in master.columns:
    # OPENCODE: set bucket edges and labels for this project
    bins   = [⟨FILL: bucket_edge_1⟩, ⟨FILL: bucket_edge_2⟩, ⟨FILL: bucket_edge_3⟩, float("inf")]
    labels = ["⟨FILL: label_1⟩", "⟨FILL: label_2⟩", "⟨FILL: label_3+⟩"]
    master["performance_bucket"] = pd.cut(master[operational_col], bins=bins, labels=labels)

    perf_sat = (
        master.groupby("performance_bucket", observed=True)
        .agg(
            avg_satisfaction=(sat_col, "mean"),
            record_count=(count_col, "count"),
            negative_rate=(sat_col, lambda x: (x <= ⟨FILL: negative_threshold⟩).mean() * 100),
        )
        .reset_index()
        .round(2)
    )
    save_csv(perf_sat, "eda_operational_vs_satisfaction.csv", "eda_out")
    eda_results["perf_sat"] = perf_sat

    fig_perf_sat = px.bar(
        perf_sat, x="performance_bucket", y="avg_satisfaction",
        color="avg_satisfaction", color_continuous_scale="RdYlGn",
        title="⟨FILL: operational metric⟩ vs ⟨FILL: satisfaction metric⟩")
    fig_perf_sat.update_layout(plot_bgcolor="white", coloraxis_showscale=False)
    save_chart(fig_perf_sat, "eda_operational_vs_satisfaction.html")

# ── STEP 3: OUTLIER DETECTION ─────────────────────────────────────────────────

log("STEP 3 — OUTLIER DETECTION", section=True)

valid_outlier_cols = [c for c in OUTLIER_COLUMNS if c in master.columns]
outlier_report = []
all_outlier_flags = pd.DataFrame(index=master.index)

for col in valid_outlier_cols:
    series = master[col].dropna()

    if OUTLIER_METHOD == "iqr":
        Q1, Q3 = series.quantile(0.25), series.quantile(0.75)
        IQR = Q3 - Q1
        lower = Q1 - OUTLIER_IQR_MULTIPLIER * IQR
        upper = Q3 + OUTLIER_IQR_MULTIPLIER * IQR
        method_label = f"IQR ×{OUTLIER_IQR_MULTIPLIER}"
    else:
        lower = series.mean() - OUTLIER_ZSCORE_THRESHOLD * series.std()
        upper = series.mean() + OUTLIER_ZSCORE_THRESHOLD * series.std()
        method_label = f"Z-score >{OUTLIER_ZSCORE_THRESHOLD}"

    flag_col = f"outlier_{col}"
    all_outlier_flags[flag_col] = ((master[col] < lower) | (master[col] > upper)).astype(int)
    n_out = int(all_outlier_flags[flag_col].sum())
    pct_out = round(n_out / len(master) * 100, 2)

    outlier_report.append({
        "column":        col,
        "method":        method_label,
        "lower_bound":   round(lower, 2),
        "upper_bound":   round(upper, 2),
        "outlier_count": n_out,
        "outlier_pct":   pct_out,
        "min_value":     round(series.min(), 2),
        "max_value":     round(series.max(), 2),
        "plain_english": (
            f"{n_out:,} records ({pct_out:.1f}%) have {col.replace('_', ' ')} "
            f"outside the normal range of {round(lower,1)} to {round(upper,1)}"
        )
    })
    log(f"{col}: {n_out:,} outliers ({pct_out:.1f}%) — range [{round(lower,1)}, {round(upper,1)}]")

outlier_df = pd.DataFrame(outlier_report)
save_csv(outlier_df, "outlier_report.csv", "eda_out")

flagged_rows = master.join(all_outlier_flags)[all_outlier_flags.any(axis=1)]
save_csv(flagged_rows, "outlier_flagged_rows.csv", "eda_out")
log(f"Total rows flagged: {len(flagged_rows):,}")

fig_box = make_subplots(rows=2, cols=3,
    subplot_titles=[c.replace("_", " ").title() for c in valid_outlier_cols[:6]])
for i, col in enumerate(valid_outlier_cols[:6]):
    r, c_pos = divmod(i, 3)
    fig_box.add_trace(go.Box(y=master[col].dropna(), name=col,
                              boxpoints="outliers", marker_color="#0f172a"),
                      row=r+1, col=c_pos+1)
fig_box.update_layout(title="Outlier Distribution — Numeric Columns",
                       showlegend=False, plot_bgcolor="white")
save_chart(fig_box, "outlier_boxplots.html")

# ── STEP 4: KPI CALCULATION ───────────────────────────────────────────────────

log("STEP 4 — KPI CALCULATION", section=True)

# OPENCODE: build one KPI table block per KPI in CLAUDE.md Section 5
# Follow this pattern for each KPI:

# KPI 1 — ⟨FILL: KPI 1 name⟩
kpi_1_periodic = (
    master.groupby(time_period_col)
    .agg(
        ⟨FILL: kpi_1_column⟩=(primary_value_col, "⟨FILL: sum/mean/count⟩"),
        ⟨FILL: supporting_column⟩=(count_col, "count"),
    )
    .reset_index()
    .sort_values(time_period_col)
)
kpi_1_periodic["mom_change_pct"] = kpi_1_periodic["⟨FILL: kpi_1_column⟩"].pct_change().mul(100).round(2)
kpi_1_periodic = kpi_1_periodic.round(2)
save_csv(kpi_1_periodic, "kpi_⟨FILL: KPI_1_slug⟩_by_period.csv")

kpi_1_summary = pd.DataFrame([{
    "grand_total_⟨FILL: kpi_1_slug⟩": round(master[primary_value_col].⟨FILL: sum/mean⟩(), 2),
    "best_period":                      trend.loc[trend["total_value"].idxmax(), time_period_col],
    "worst_period":                     trend.loc[trend["total_value"].idxmin(), time_period_col],
    "growth_rate_pct":                  round(
        (trend["total_value"].iloc[-1] - trend["total_value"].iloc[0])
        / trend["total_value"].iloc[0] * 100, 2),
}])
save_csv(kpi_1_summary, "kpi_⟨FILL: KPI_1_slug⟩_summary.csv")

# KPI 2 — ⟨FILL: KPI 2 name⟩
# OPENCODE: repeat pattern above for each KPI
# ⟨FILL: KPI 2 calculation block⟩

# KPI 3 — ⟨FILL: KPI 3 name⟩
# ⟨FILL: KPI 3 calculation block⟩

# KPI 4 — ⟨FILL: KPI 4 name — entity retention/repeat rate⟩
new_entities       = (entity_behaviour["entity_type"] == "new").sum()
returning_entities = (entity_behaviour["entity_type"] == "returning").sum()
total_entities     = len(entity_behaviour)
repeat_rate        = round(returning_entities / total_entities * 100, 2)
avg_value_new      = round(entity_behaviour[entity_behaviour["entity_type"] == "new"]["total_value"].mean(), 2)
avg_value_returning= round(entity_behaviour[entity_behaviour["entity_type"] == "returning"]["total_value"].mean(), 2)

# What-if projection
target_repeat_pct    = ⟨FILL: target repeat rate as decimal × 100, e.g. 10.0⟩
additional_returning = int((target_repeat_pct / 100 * total_entities) - returning_entities)
projected_uplift     = round(additional_returning * avg_value_returning, 2)

kpi_retention = pd.DataFrame([{
    "total_unique_⟨FILL: entity_label⟩": total_entities,
    "new_⟨FILL: entity_label⟩":          int(new_entities),
    "returning_⟨FILL: entity_label⟩":    int(returning_entities),
    "repeat_rate_pct":                    repeat_rate,
    "avg_value_new":                      avg_value_new,
    "avg_value_returning":                avg_value_returning,
    "whatif_target_pct":                  target_repeat_pct,
    "whatif_additional_returning":        additional_returning,
    "whatif_revenue_uplift":              projected_uplift,
    "note":                               "PROJECTION — not from source data",
}])
save_csv(kpi_retention, "kpi_⟨FILL: entity_slug⟩_retention_summary.csv")

# KPI Master Dashboard — one row, all headline values
# OPENCODE: add one key per KPI defined in CLAUDE.md Section 5
kpi_master = pd.DataFrame([{
    "⟨FILL: kpi_1_label⟩":   round(master[primary_value_col].sum(), 2),
    "⟨FILL: kpi_2_label⟩":   round(master[primary_value_col].mean(), 2),
    "⟨FILL: kpi_3_label⟩":   round((master[perf_flag_col] == 0).mean() * 100, 2),
    "⟨FILL: kpi_4_label⟩":   round(master[sat_col].mean(), 2),
    "⟨FILL: kpi_5_label⟩":   repeat_rate,
    # OPENCODE: add remaining KPIs
}])
save_csv(kpi_master, "KPI_MASTER_DASHBOARD.csv")

# ── STEP 5: EXECUTIVE SUMMARY ─────────────────────────────────────────────────

log("STEP 5 — EXECUTIVE SUMMARY", section=True)

summary = f"""
⟨FILL: PROJECT NAME⟩ — ANALYSIS AGENT SUMMARY
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}
{'='*60}

DATASET
  Records analysed:  {len(master):,}
  Date range:        {master['⟨FILL: primary_date_column⟩'].min().date()} → {master['⟨FILL: primary_date_column⟩'].max().date()}
  Unique ⟨FILL: entity label, e.g. customers⟩: {total_entities:,}

HEADLINE KPIs
  ⟨FILL: KPI 1 label⟩:   {kpi_master['⟨FILL: kpi_1_label⟩'].iloc[0]:>12,.2f}
  ⟨FILL: KPI 2 label⟩:   {kpi_master['⟨FILL: kpi_2_label⟩'].iloc[0]:>12,.2f}
  ⟨FILL: KPI 3 label⟩:   {kpi_master['⟨FILL: kpi_3_label⟩'].iloc[0]:>11.1f}%
  ⟨FILL: KPI 4 label⟩:   {kpi_master['⟨FILL: kpi_4_label⟩'].iloc[0]:>12.2f}
  ⟨FILL: KPI 5 label⟩:   {kpi_master['⟨FILL: kpi_5_label⟩'].iloc[0]:>11.1f}%

KEY FINDINGS
  1. ⟨FILL: trend finding — OpenCode writes this from actual computed values above⟩
  2. ⟨FILL: operational finding⟩
  3. ⟨FILL: satisfaction / quality finding⟩
  4. ⟨FILL: retention finding with projection⟩
  5. ⟨FILL: geographic concentration finding⟩

OUTLIER FLAGS
"""

for _, row in outlier_df.iterrows():
    if row["outlier_count"] > 0:
        summary += f"  {row['plain_english']}\n"

summary += f"""
OUTPUTS SAVED
  KPI tables:    02_Cleaned_Data/kpi_tables/ ({len(os.listdir(PATHS['kpi_out']))} files)
  EDA outputs:   07_AI_Outputs/
  Charts:        07_AI_Outputs/charts/ ({len(os.listdir(PATHS['charts_out']))} files)
{'='*60}
"""

print(summary)

summary_path = os.path.join(PATHS["eda_out"], "agent_executive_summary.md")
with open(summary_path, "w", encoding="utf-8") as f:
    f.write(summary)
log("Summary saved: agent_executive_summary.md")

log("\nAGENT COMPLETE — All outputs saved.", section=True)
